
using System.Net;
using System.Net.Mail;
using System.Text;
using MySql.Data.MySqlClient;

public class mqSubscribeService
{
    rabbitService _rs;
    dbServices _db = new dbServices();
    public mqSubscribeService()
    {
        IConfiguration appsettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build(); // this is to read the rabbit settings from settings file 
        Dictionary<string, string> settings = new Dictionary<string, string>();
        settings["HostName"] = appsettings["rabbit:HostName"];
        settings["UserName"] = appsettings["rabbit:UserName"];
        settings["VirtualHost"] = appsettings["rabbit:VirtualHost"];
        settings["Password"] = appsettings["rabbit:Password"];
        settings["Port"] = appsettings["rabbit:Port"];
        rabbitService _rs = new rabbitService(settings);


        _rs.subscribeQueue("generate_otp_and_email", false, onMessageRecievedGenOTP);
        bool onMessageRecievedGenOTP(Dictionary<string, object> recievedData)
        {
            try
            {
                var email_id = recievedData["email_id"].ToString();
                var trans_id = recievedData["trans_id"].ToString();
                var guid = recievedData["guid"].ToString(); // work on this to convert it from json
                var msg_id = recievedData["msg_id"].ToString(); // work on this to convert it from json

                MySqlParameter[] myParams = new MySqlParameter[] {
                new MySqlParameter("@emailID",email_id),
                new MySqlParameter("@trans_id",Int32.Parse(trans_id)),
                new MySqlParameter("@msg_id",Int32.Parse(msg_id)),
                new MySqlParameter("@guid",guid),
                };

                var sq = @"call generateOTP(@emailID,@trans_id,@msg_id,@guid)"; // this will insert a generated otp into the table 
                var dbdata = _db.executeSQL(sq, myParams);
                if (dbdata == null) // error occured
                    return false; /// send negative ack as some database error
                else
                {
                    var msg = dbdata[0][0][2].ToString().Replace("<<OTP>>", dbdata[1][0][1].ToString()); // message template replace the otp wioth new otp
                    //var dta = JsonSerializer.Deserialize<List<List<Object[]>>>(recievedMsg);
                    // codes for sending mail and sending acknoledgement to the queue for removal of email 
                    MailAddress to = new MailAddress(email_id);
                    MailAddress from = new MailAddress(appsettings["mail:Mail"]);
                    MailMessage message = new MailMessage(from, to);
                    message.Subject = dbdata[0][0][3].ToString();
                    message.Body = msg;
                    SmtpClient client = new SmtpClient(appsettings["mail:SMTP"]);
                    client.Port = Int32.Parse(appsettings["mail:Port"]);
                    client.Credentials = new NetworkCredential(appsettings["mail:Mail"], appsettings["mail:Password"]);
                    client.EnableSsl = true;
                    // code in brackets above needed if authentication required
                    client.Send(message);
                    return true;// send acknoledgement 

                }
            }
            catch (SmtpException ex)
            {
                Console.WriteLine(ex.ToString());
                return false;// send negative ack to rabbit

            }
        }

        // payload of rabbit message will be body of mail
        // properties.header will have 

        _rs.subscribeQueue("send_email", false, onMessageRecievedSendEmail);
        bool onMessageRecievedSendEmail(Dictionary<string, object> recievedData)
        {
            try
            {
                //Dictionary<string,object> headers = (Dictionary<string,object>)recievedProps["headers"];
                var email_id = recievedData["email_id"].ToString();
                var subject = recievedData["subject"].ToString();
                var msg = recievedData["mail"].ToString(); // work on this to convert it from json
                MailAddress to = new MailAddress(email_id);
                MailAddress from = new MailAddress(appsettings["mail:Mail"]);
                MailMessage message = new MailMessage(from, to);
                message.Subject = subject;
                message.Body = msg;
                SmtpClient client = new SmtpClient(appsettings["mail:SMTP"]);
                client.Port = Int32.Parse(appsettings["mail:Port"]);
                client.Credentials = new NetworkCredential(appsettings["mail:Mail"], appsettings["mail:Password"]);
                client.EnableSsl = true;
                // code in brackets above needed if authentication required
                client.Send(message);
                return true;// send acknoledgement 

            }
            catch (SmtpException ex)
            {
                Console.WriteLine(ex.ToString());
                return false;// send negative ack to rabbit

            }
        }




    }

}