
using MySql.Data.MySqlClient;

public class emailService
{
    // rabbitService _rs;
    dbServices _db = new dbServices();
    public emailService()
    {
        //_db=new dbServices();
        //IConfiguration appsettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

    }

    public async Task<responseData> validateEmailOTP(requestData reqData)
    {
        responseData resData = new responseData();
        resData.rStatus = 0;

        MySqlParameter[] myParams = new MySqlParameter[] {
            new MySqlParameter("@emailID",reqData.addInfo["email_id"].ToString()),
            new MySqlParameter("@trans_id",Int32.Parse(reqData.addInfo["trans_id"].ToString())),
            new MySqlParameter("@msg_id",Int32.Parse(reqData.addInfo["msg_id"].ToString())),
            new MySqlParameter("@guid",reqData.addInfo["guid"].ToString()),
            new MySqlParameter("@otp",Int32.Parse(reqData.addInfo["otp"].ToString())),
            };

        // call VerifyOTP(@emailID,@trans_id,@msg_id,@guid,@otp)
        var sq = @"call verifyOTP(@emailID,@trans_id,@msg_id,@guid,@otp)";
        var dbdata = _db.executeSQL(sq, myParams);
        if (dbdata == null) // error occured
            resData.rStatus = 101; // second database error
        else
        {
            resData.rData["rCode"] = dbdata[0][0][0];
            resData.rData["rMessage"] = dbdata[0][0][1];
        }

        return resData;
    }



}