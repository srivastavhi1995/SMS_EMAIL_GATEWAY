
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using System.ComponentModel.DataAnnotations;


WebHost.CreateDefaultBuilder().
ConfigureServices(s =>
{

    //IConfiguration appsettings = new ConfigurationBuilder()
    //                        .AddJsonFile("Properties/appsettings.json")
    //                        .Build();

    s.AddSingleton<mqSubscribeService>();// this will start listining to email ques for new email otps to be sent
    s.AddSingleton<emailService>();
    s.AddCors();
    s.AddControllers();

}).
Configure(app =>
{
    app.UseRouting();

    app.UseCors(options =>
        options.WithOrigins("http://localhost:8000", "https://localhost:8000", "https://localhost:5001", "http://localhost:5000").AllowAnyHeader().AllowAnyMethod().AllowCredentials());

    app.UseEndpoints(e =>
    {
        var mqService = e.ServiceProvider.GetRequiredService<mqSubscribeService>();
        var EmailService = e.ServiceProvider.GetRequiredService<emailService>();
        //var homeSrv = e.ServiceProvider.GetRequiredService<homeSrv>();
        //var testService = e.ServiceProvider.GetRequiredService<TestServiceRequest>();
        try
        {
            e.MapPost("/ValidateEmailOTP",
            [AllowAnonymous] async (HttpContext http) =>
            {
                var body = await new StreamReader(http.Request.Body).ReadToEndAsync();
                //var dta = JsonSerializer.Deserialize<List<List<Object[]>>>(body);
                requestData rData = JsonSerializer.Deserialize<requestData>(body);
                await http.Response.WriteAsJsonAsync(await EmailService.validateEmailOTP(rData));
            });
            e.MapGet("/test",
                async c => await c.Response.WriteAsJsonAsync("{'Status':'0','Message':'API Link Up and Running'}"));
            e.MapDefaultControllerRoute();

        }
        catch (Exception ex)
        {
            Console.Write(ex);
        }


    });
}).Build().Run();

public record requestData
{ //request data
  //SOURCE.srv.fn_CS({ rID: "F000", rData: {encData: encrypted}}, page_OS, $("#progressBarFooter")[0]);
    [Required]
    public string eventID { get; set; } //  request ID this is the ID of entity requesting the API (UTI/CDAC/CAC) this is used to pick up the respective private key for the requesting user
    [Required]
    public IDictionary<string, object> addInfo { get; set; } // request data .. previously addInfo 
}

public record responseData
{ //response data
    public responseData()
    { // set default values here
        eventID = "";
        rStatus = 0;
        rData = new Dictionary<string, object>();

    }
    [Required]
    public int rStatus { get; set; } = 0; // this will be defaulted 0 fo success and other numbers for failures
    [Required]
    public string eventID { get; set; } //  response ID this is the ID of entity requesting the
    public IDictionary<string, object> addInfo { get; set; } // request data .. previously addInfo 
    public Dictionary<string, object> rData { get; set; }
    //public ArrayList rData {get;set;}
}

